docker ps

docker exec -it 2ea8a3b2c2de /bin/sh

cd ../

cd var/lib/pgadmin/storage/root_root.com

docker cp 2ea8a3b2c2de:/var/lib/pgadmin/storage/root_root.com D:\Projects\lorawan-testbed\app-server\db\create-db