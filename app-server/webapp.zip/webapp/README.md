//nodemon ./bin/www localhost 8080

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard</title>
    <link rel='stylesheet' href='/stylesheets/dashboard.css' />
    <% include ../partials/libs%>
</head>

<body>
    <% include ../partials/navbar%>
    <% include ../partials/header%>

    <% include ../partials/footer%>
</body>

</html> -->

<%- include ('../partials/libs') %>